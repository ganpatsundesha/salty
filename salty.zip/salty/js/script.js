$(document).ready(function() {
    $('.autoplay').slick({
        slidesToShow: 3,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 3000,
        dots: true,
        pauseOnHover: false,
        responsive: [{
                breakpoint: 1023,
                settings: {
                    slidesToShow: 2
                }
            },
            {
                breakpoint: 577,
                settings: {
                    centerPadding: '40px',
                    slidesToShow: 1
                }
            }
        ]
    });
    $('.categories-slider').slick({
        slidesToShow: 6,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 3000,
        dots: true,
        pauseOnHover: false,
        responsive: [{
                breakpoint: 767,
                settings: {
                    slidesToShow: 4
                }
            },
            {
                breakpoint: 479,
                settings: {
                    slidesToShow: 2
                }
            }
        ]
    });
    $('.testimonial-slider').slick({
        dots: true,
        infinite: true,
        speed: 300,
        fade: true,
        cssEase: 'linear'
    });
    $('#responsiveTabsDemo').responsiveTabs({
        startCollapsed: 'accordion'
    });
    $('.menu-toggle').click(function() {
        $('body').toggleClass('nav-on');

    });
});